//====================
// Đổi giao diện
//====================

const btn = document.getElementById("themeToggle");

const icon = btn.querySelector("i");

btn.onclick=function(){

    document.body.classList.toggle("dark");

    if(document.body.classList.contains("dark")){

        icon.classList.remove("fa-moon");
        icon.classList.add("fa-sun");

    }else{

        icon.classList.remove("fa-sun");
        icon.classList.add("fa-moon");

    }

}

//====================
// Tìm kiếm thành viên
//====================

const input=document.getElementById("searchMember");

const members=document.querySelectorAll(".member-card");

input.addEventListener("keyup",function(){

    let value=this.value.toLowerCase();

    members.forEach(function(card){

        let text=card.innerText.toLowerCase();

        if(text.includes(value)){

            card.style.display="block";

        }else{

            card.style.display="none";

        }

    });

});